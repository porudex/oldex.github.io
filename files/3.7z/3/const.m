%const supply analysis
%SCS-15
%Olejnik D.I. & Dorozhenkov P.A.
clear;
clc;
r1=30;
r2=200;
%C=20e-6;
%L=5e-3;
rvn=1e-1;
rn = 1e5;
Uvh=10;
g=[1/rvn+1/r1 -1/r1;...
      -1/r1 1/r1+1/r2+1/rn];
n=0;
for uvh=0:1:10
n=n+1;
s=[uvh/rvn; 0];
fi(:,n)=inv(g)*s;
end;
plot(fi(2,:),fi(1,:));
grid;
title('Uvih|Uvh');
xlabel('U(1),B');
ylabel('U(2),B');
