clear;
r1=50;
r2=200;
rn=100e3;
rvn=0.1;
uvh=100;
g=[1/rvn+1/r2    -1/r2;...
   -1/r2   1/r2+1/rn];
n=0;
for uvh=0:1:100
n=n+1;
s=[uvh/rvn; 0];
fi(:,n)=inv(g)*s;
end;
plot(fi(2,:),fi(1,:));
grid;
title('zavisimost na vihode.');
xlabel('U(1), �');
ylabel('U(2), �');
