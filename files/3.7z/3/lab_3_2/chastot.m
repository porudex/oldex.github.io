clear;
r1=50;
r2=200;
c=10*10^-8;
l=5*10^-2;
rvn=0.1;
rn=100e3;
f=240;
e=10;
%������ �������
w=2*pi*f;
g=[1/rvn+1/r1-i/w*l   i/w*l-1/r1   0;...
   i/w*l-1/r1         1/r1+1/r2-i/w*l   -1/r2;...
   0                 -1/r2       1/r2+i*w*c+1/rn];
s=[e/rvn; 0; 0];
u=inv(g)*s;
tkon=3/f;
n=0;
for t=0:0.000001:tkon
   n=n+1;
   u2(n)=abs(u(2))*sin(w*t+angle(u(2)));
   u1(n)=abs(e)*sin(w*t);
   time(n)=t;
end
figure (1);
plot(time(1:n),u2(1:n),time(1:n),u1(1:n));
grid;
title ('napryaj na vhode');
xlabel ('time t, �');
ylabel ('U vhod, U vihod');
%������ ��������� �������������
fnach=10;
df=100;
fkon=100000;
n=0;
for f=fnach:df:fkon
   n=n+1;
   w=2*pi*f;
  g=[1/rvn+1/r1-i/w*l   i/w*l-1/r1   0;...
   i/w*l-1/r1         1/r1+1/r2-i/w*l   -1/r2;...
   0                 -1/r2       1/r2+i*w*c+1/rn];
    fi(:,n)=inv(g)*s;
   k(n)=20*log10(abs(fi(3,n))/abs(e));
   psi(n)=angle(fi(3,n))*180/pi;
   ff(n)=f;
end
figure (2);
subplot(2,1,1);
semilogx(ff(1:n),k(1:n));
grid;
title('ACH');
ylabel('amplitude');
subplot(2,1,2);
semilogx(ff(1:n),psi(1:n));
grid;
title('FCH');
ylabel('faza');
xlabel('chastota');
