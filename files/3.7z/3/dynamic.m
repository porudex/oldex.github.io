%dynamic analysis
%SCS-15
%Olejnik D.I. & Dorozhenkov P.A.
clear;
clc;
r1=30;
r2=200;
c=20e-6;
l=5e-3;
rvn=1e-1;
rn = 1e5;
um=10;
f=1e2;
h=2*pi*sqrt(l*c)/100;
tnach=0;
np=2;
tkon=np/f;
nharm=20;
n=0;
il=0;
uc=0;
g=[1/rvn+h/l -h/l 0;...
      -h/l h/l+c/h+1/r1 -1/r1;...
      0 -1/r1 1/r1+1/r2+1/rn];
for t=tnach:h:tkon
   n=n+1;
   ucold=uc;
   fk=sign(sin(2*pi*f*t));
   s=[um*fk/rvn+il; -il+c*uc/h; 0];
   fi(:,n)=inv(g)*s;
   uc=fi(2,n);
   il=il-(fi(1,n)-fi(2,n))*h/l;
   i(1,n)=il;
   i(2,n)=c*(uc-ucold)/h;
   i(3,n)=fi(3,n)/rn;
end
t=tnach:h:tkon;
figure(1);
plot(t,fi(1,:));
grid;
xlabel('t, c');
ylabel('Uvh, B');
figure(2);
plot(t,i(1,:));
grid;
xlabel('t, c');
ylabel('Ivh, A');
figure(3);
plot(t,fi(2,:));
grid;
xlabel('t, c');
ylabel('Uc, B');
figure(4);
plot(t,i(2,:));
grid;
xlabel('t, c');
ylabel('Ic, A');
figure(5);
plot(t,fi(3,:));
grid;
xlabel('t, c');
ylabel('Uvih, B');
figure(6);
plot(t,i(3,:));
grid;
xlabel('t, c');
ylabel('In, A');
figure(7);
ah=(abs(fft(i(3,:)))/max(abs(fft(i(3,:)))))*100;
frec=0:f/np:nharm*f/np;
bar(frec,ah(1:nharm+1));
grid;
title('Spectr In');
xlabel('F, Hz');
ylabel('Amplitude by main harm, %');
